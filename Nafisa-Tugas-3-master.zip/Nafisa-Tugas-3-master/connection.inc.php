<?php
$host = "localhost";
$port = "5432";
$dbname = "lampung";
$user = "postgres";
$password = "123";
